﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp184384385843
{
    class Program
    {
        static void Main(string[] args)
        {
            //int x = 1;
            //while (x <= 10)
            //{
            //    Console.WriteLine(x);
            //    x = x + 1;
            //}
            //Console.Read();

            //Console.Write("Введите до какого числа - ");
            //int a = int.Parse(Console.ReadLine());
            //int x = 1;
            //while (x <= a)
            //{
            //    Console.WriteLine(x);
            //    x = x + 1;
            //}
            //Console.Read();

            //int a = 1;
            //Console.ForegroundColor = ConsoleColor.Green;
            //while (a <= 5)
            //{
            //    Console.WriteLine("Привет!");
            //    a ++;
            //}
            //Console.Read();

            //int a = 1;
            //while (a <= 18)
            //{
            //    Console.Write("#");
            //    a++;
            //}
            //Console.Read();

            //int a = 1;
            //Console.ForegroundColor = ConsoleColor.Green;
            //while (a <= 25)
            //{
            //    Console.WriteLine("#");
            //    a++;
            //}
            //Console.Read();
        }
    }
}
